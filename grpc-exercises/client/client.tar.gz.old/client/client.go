/* Simple single-operation grpc app that runs all of the RPC's in 6.1.1
* via gRPC.
* Questions? Ask Aaron Millisor - amilliso@cisco.com
*
* */

package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"github.com/golang/protobuf/jsonpb"
	"github.com/golang/protobuf/proto"
	sfkr "grpc-sfkr"
	CiscoTelemetry "grpc-sfkr/telproto"
	"io/ioutil"
	"os"
)

func PrintTelemetry(telChan <-chan []byte) {
	for {
		theProto, ok := <-telChan
		if !ok {
			os.Exit(2)
		}
		ProtoItem := new(CiscoTelemetry.Telemetry)
		err := proto.Unmarshal(theProto, ProtoItem)
		var jsonpbObject jsonpb.Marshaler
		jsonString, _ := jsonpbObject.MarshalToString(ProtoItem)
		buf := new(bytes.Buffer)
		json.Indent(buf, []byte(jsonString), "", "  ")
		if err != nil {
			fmt.Println("error: ", err)
		}
		fmt.Println(buf)
	}
}

func main() {
	/* Create an instance of a router, the struct is just to
	* conveniently view all the variables. Also create a connection
	* that we will use as an argument for all the helper functions.
	 */

	var (
		device    = flag.String("device", "", "*required: Device connection json file")
		oper      = flag.String("oper", "", "*required: Operations:\tget-config\n\t\t\t\tget-oper\n\t\t\t\tshow-cmd-text\n\t\t\t\tmerge-config\n\t\t\t\tdelete-config\n\t\t\t\treplace-config\n\t\t\t\tcli-config\n\t\t\t\tfull-replace\n\t\t\t\ttelemetry")
		telpath   = flag.String("telsubid", "", "Telemetry Subscription ID (must already exist)")
		inputjson = flag.String("json", "", "input file for the operation, text JSON")
		inputcli  = flag.String("cli", "", "input file for the operation, text CLI")
	)

	flag.Parse()

	var output string
	if len(*device) < 1 {
		fmt.Println("Invalid device input filename")
	} else {
		Sunstone1 := sfkr.ReadCfg(*device)
		conn := sfkr.Connect(Sunstone1)
		if conn == nil {
			return
		}
		defer conn.Close()
		jsonFile, _ := ioutil.ReadFile(*inputjson)
		cliFile, _ := ioutil.ReadFile(*inputcli)
		inputJsonFile := string(jsonFile)
		inputCliFile := string(cliFile)

		if len(inputJsonFile) < 1 || len(inputCliFile) < 1 {
			//catch when the input file isn't big enough to be a
			//json object with a filter

			if len(inputJsonFile) < 1 && len(inputCliFile) < 1 {
				switch *oper {
				case "full-replace":
					fmt.Println("Not enough arguments for 'full-replace'")
					os.Exit(2)

				}
			}
			if len(inputJsonFile) < 1 {
				switch *oper {
				case "get-oper", "merge-config", "replace-config", "commit-replace":
					fmt.Println("Not enough arguments for YANG operation")
					os.Exit(2)
				}
			}
			if len(inputCliFile) < 1 {
				switch *oper {
				case "show-cmd-text", "cli-config":
					fmt.Println("Not enough arguments for CLI command")
					os.Exit(2)
				}
			}
		}
		var err error
		switch *oper {
		case "get-config":
			{
				output, err = sfkr.GetYANGConfig(conn, inputJsonFile)
			}
		case "get-oper":
			{
				output, err = sfkr.GetYANGOper(conn, inputJsonFile)
			}
		case "merge-config":
			{
				_, err = sfkr.SetYANGConfig(conn, "merge", inputJsonFile)
			}
		case "replace-config":
			{
				_, err = sfkr.SetYANGConfig(conn, "replace", inputJsonFile)
			}
		case "delete-config":
			{
				_, err = sfkr.SetYANGConfig(conn, "delete", inputJsonFile)
			}
		case "show-cmd-text":
			{
				output, err = sfkr.GetShowCmd(conn, inputCliFile)
			}
		case "cli-config":
			{
				_, err = sfkr.SetCLIConfig(conn, inputCliFile)
			}
		case "full-replace":
			{
				_, err = sfkr.SetFullConfigReplace(conn, inputCliFile, inputJsonFile)
			}
		case "telemetry":
			{
				if len(*telpath) < 1 {
					fmt.Println("missing telemetry subscription id argument")
					os.Exit(2)
				} else {
					telChan, _ := sfkr.GetStreamingTelemetry(conn, *telpath)
					PrintTelemetry(telChan)
					os.Exit(0)
				}
			}
		default:
			{
				fmt.Println("Invalid operation, use --help to figure out arguments")
				os.Exit(2)
			}
		}
		if err != nil {
			fmt.Println(err)
		}

	}
	fmt.Println(output)

}
